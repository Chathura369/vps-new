# V2Ray for Heroku
This image is based on Alpine, making it as light as possible.

## One-Click button
[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)

## Note
This trick heavily relies on the domain of `herokuapp.com`. \
Thus please **DO NOT** distribute this repo everywhere in case the domain is blocked.

## Warning
Since Heroku has updated its TOS, your account will be suspended if you deploy any proxy server including shadowsocks and v2ray.
